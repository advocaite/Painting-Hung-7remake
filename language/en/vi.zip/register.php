<?php

//mock register for auth system  by advocaite
//what this file dose is registers the user name and passwords to one table
// and email username and other stuff to profile the custermer id is important 
//skype:advocaite
//sanitise the inputs before you release
//also make sure this db conection points to the auth db sql file in release
$conn = mysql_connect("localhost","",")");   //"localhost","DATABASE USERNAME","DATABASE PASSWORD"
mysql_select_db() or die(mysql_error());

function checkIfExists($field,$value) {
    $sql = mysql_query("SELECT * FROM auth WHERE $field='$value'");
    
    if( mysql_num_rows($sql) > 0 ) {
        return true;
    } else {
        return false;
    }
}

 if($_POST['submit']) {
    if( !$_POST['username'] ){
        $error = "You did not enter a username";
    } else if( checkIfExists('username',$_POST['username']) ){
        $error = "Username already taken.";
    } else if( empty($_POST['password']) ){
        $error = "You did not enter a password.";
    } else if( $_POST['password'] != $_POST['confirmpassword'] ){
        $error = "The passwords you gave do not match.";
    } else if( !$_POST['email'] ){
        $error = "You did not give a username.";
    } else if( $_POST['email'] != $_POST['email2'] ){
        $error = "Email addresses do not match";
    } else if( !preg_match("/^.+?@.+?\..+?/i",$_POST['email']) ){
        $error = "Please enter a valid email address, in the correct format.";
    } else {
        
        //Create the user account
        $timenow = time();
        $regip = $_SERVER['REMOTE_ADDR'];
        $uniqueLink = rand(1222222,9999999);
        $encpass = md5($_POST['password']);
        $actkey = rand(1222222,9999999);

        
        mysql_query("INSERT INTO auth SET username='{$_POST['username']}',password='$encpass',refID='$referrerID' ,uniqueLink='$uniqueLink'");
        $customerID = mysql_insert_id();
        mysql_query("INSERT INTO profiles SET customerID='$customerID',email='{$_POST['email']}',username='".$_POST[username]."',actkey='$actkey'");
        $done =1; 
    
    }
}
?>

        	<h4>Register Account</h4>

        	
<?php
if( isset($error) ){
	echo "<div >
           	  <div >
               	  $error	  </div>";
}
 ?> 
<?php
if( isset($done) ){
	echo "<div >
           	  <div >
               	  Account registered. <a href=\"http://game.yourdomain.com\login.php\">click here</a> to goto game and fun now.
			  </div>
            </div>";
}
 ?>           

                    <br>
                    <br>
                	Your email address will not be published. Required fields are marked <span style="color:red;">*</span>
                    <br />
                    <form method="POST" action="">
                        Gamer Name<span style="color:red;">*</span>
                    <input type="text" name="username" id="username"  /><br />
                        Email<span style="color:red;">*</span>
                    <input type="text" name="email" id="email"  /><br />
                        Confirm Email<span style="color:red;">*</span>
                    <input type="text" name="email2" id="email2"  /><br />
                        Password<span style="color:red;">*</span>
                    <input type="password" name="password" id="password"  /><br />
                        Confirm Password<span style="color:red;">*</span>
                    <input type="password" name="confirmpassword" id="confirmpassword"  /><br />
                    <input type="submit" name="submit" id="submit" value="Register"  />
                    </form>
        